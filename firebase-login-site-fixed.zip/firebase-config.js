
// Firebase konfiguracija brez export
const firebaseConfig = {
  apiKey: "AIzaSyD-LU4Vun6SKFSIhHEVquEkS-MStox9D84",
  authDomain: "igre-registracija.firebaseapp.com",
  projectId: "igre-registracija",
  storageBucket: "igre-registracija.firebasestorage.app",
  messagingSenderId: "365182438160",
  appId: "1:365182438160:web:154b54a56501f54fbb3395",
  measurementId: "G-32X03N3HR6"
};
// Inicializacija Firebase
firebase.initializeApp(firebaseConfig);
